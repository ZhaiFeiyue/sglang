make clean
make html
python3 -m http.server --d _build/html
