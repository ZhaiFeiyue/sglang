raise ValueError("bench_latency.py has been renamed to bench_one_batch.py")
